﻿using BLL.Entity;

namespace BLL.Interfaces.Repository
{
    public interface ICartRepository : IBaseRepository<Cart>
    {
    }
}
