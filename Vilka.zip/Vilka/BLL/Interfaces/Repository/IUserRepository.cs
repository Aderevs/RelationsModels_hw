﻿using BLL.Entity;

namespace BLL.Interfaces.Repository
{
    public interface IUserRepository : IBaseRepository<User>
    {
    }
}
