﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DAL_V3.Migrations
{
    public partial class Data : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
