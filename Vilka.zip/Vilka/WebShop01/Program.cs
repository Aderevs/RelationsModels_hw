using BLL;

using WebShop01.Interfaces;
using WebShop01.Services;


using Serilog;
using Serilog.Events;
using System.Data;
using BLL.Entity;

using DAL_V2.Entity;

namespace WebShop01
{
    public class Program
    {
        public static void Main(string[] args)
        {
            FillDatabase();
            var builder = WebApplication.CreateBuilder(args);

            IConfiguration configuration = builder.Configuration;
            builder.Services.AddBusinessLogicLayer(configuration);
            builder.Services.AddAutoMapper(typeof(AutoMapperProfile));


            builder.Services.AddControllersWithViews();
            builder.Services.AddRazorPages().AddRazorRuntimeCompilation();


            builder.Host.UseSerilog((ctx, lg) =>
            {
                lg.WriteTo.Console(LogEventLevel.Error);
                lg.WriteTo.Seq("http://localhost:4000", LogEventLevel.Error);
            });


            var app = builder.Build();



            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Shop}/{action=Index}/{category?}");

            app.Run();
        }
        public static void FillDatabase()
        {
            using DAL_V2.EntityDatabase db = new DAL_V2.EntityDatabase();
            #region creating instances
            //USERS
            Guid[] userIds = new Guid[2];
            for (int i = 0; i < userIds.Length; i++)
            {
                userIds[i] = Guid.NewGuid();
            }
            DAL_V2.Entity.User[] users =
            {
                        new DAL_V2.Entity.User
                        {
                            Id = userIds[0],
                            Name= "Ben",
                            Login = "qwerty",
                            Password = "pass1212",
                            Email = "trin@gmai.com"
                        },
                        new DAL_V2.Entity.User
                        {
                            Id = userIds[1],
                            Name = "Ron",
                            Login = "zxcvbn",
                            Password = "word3232",
                            Email = "kipin@yahoo.com"
                        }
                };

            //CATEGORIES
            Guid[] categoryIds = new Guid[3];
            for (int i = 0; i < categoryIds.Length; i++)
            {
                categoryIds[i] = Guid.NewGuid();
            }
            DAL_V2.Entity.Category[] categories =
            {
                    new DAL_V2.Entity.Category
                    {
                        Id = categoryIds[0],
                        Name = "Computers"
                    },
                    new DAL_V2.Entity.Category
                    {
                        Id = categoryIds[1],
                        Name = "Garden equipment"
                    },
                    new DAL_V2.Entity.Category
                    {
                        Id = categoryIds[2],
                        Name = "Household chemicals"
                    }
                };

            //PRODUCTS
            Guid[] productIds = new Guid[7];
            for (int i = 0; i < productIds.Length; i++)
            {
                productIds[i] = Guid.NewGuid();
            }
            var imgUrl = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8PEA0NDQ0NDQ0NDQ0NDQ0NDQ8NDQ0NFREWFhURFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDQ0OFw8QFS0dFR4uLi0rKy0rKy0tKy0tLS0rLS0tKy0tLi0rLTctNy04KystLS0rKy0rKysrKy0tLS0rLv/AABEIAKIBNwMBIgACEQEDEQH/xAAcAAEBAAIDAQEAAAAAAAAAAAAAAQIEAwUGBwj/xABBEAACAQMBAwcICAUDBQAAAAAAAQIDBBEFEiExBgcTMkFRYSIzcXKBkaGxFCNSc5KywdFCYoKiwhVDU0SDk9Ph/8QAGQEBAQEBAQEAAAAAAAAAAAAAAAECAwQF/8QAIREBAQACAQQCAwAAAAAAAAAAAAECEVEDEhMxIUEiMmH/2gAMAwEAAhEDEQA/APXYKkXBcH0WUwMFwUDHBcFwUCYLgoAmAZACFwXAwQTBcDBcFELgoIIMFKBAUFEKXAAgKMAMDBQQQoKBAXAKIUAAAUAQoAAACgADSRQAKAABQAKAUAAAKAUgAACgAACgAA93Hd6TgqXtGHXrUoetUhH5sDnB1VblNp8OtqFmvD6TSb+DNWpy20uPG+ov1FOp+VMndOR6AHk6nONpceFepP1bat+sUbWgctLO+rO3t3W6RQlUTqU1GMkmspPL371xJ3Y8j0RQDQAoAhQAAAAAAoFIUAAAAAA0gQpUUEKFUpiUClICDIEAGR43lBy4qW11UsrbTq15VpRhKbhKX8UYyyoxhJ48pLPeexR5rQvq+U0+z6RpMvbidP8A9Zz6tuOO4Oohyt1qpuo8nrheM6V0173CKOT6fypqeb0elTX88Un/AHVkfZkinm8mfKbfHqdjytqf7NpQ9MrXd/dMyXJblXPrahZ0l4Tgvy0GfX2Qnflym3ydc32uz87ryh9067+WwWHNReS8/wAoLqS7VGFd/Ovj4H1ZnHJjdv2br5g+Zq1l57Ur6q+3EaS/MpHPQ5ndKh1p3tT1qtGP5KaPophIaO6vE0+a3Ro8barP1ru4X5ZI3aXIHSIcNOoS+8dSr+eTPTMxbLpN10tLkrplPfHTNPTXB/RKLa9rR5nlDSp0NY0V0qVOlGtQ1GjJUoRpxbjBSW5LxPeTkeI5c4jd6FW+zqEqOfvaez+hqe4Y35eiBCnrbUEKABCgCkAFBABQQAXIIUAAQDSyDHIyaRnkGJchWRTDJUwMimOQmBmMmOQBmeWrPo+UWj1FwrW1zQl7IVpL4tHpzyfKiXR6nydr9n02VFv7yVOK/Mzl1p+FR9cizI44MycscTxMxkRnG6pHMm46eOrJmDG0TJe5LheWLZi2WRxtmpY52WI2YNiTMGzcRjNniucmK6GwrPd9H1Wyq59sl82j2cmeK510/wDS7qUetTnbVF4NV4b/AIl+lx9vSthHFCptJSX8SUl7VkyTPW6MwY5GQMimGRkDMGORkDIGORkDIZMcjIGYyY5JkDNMGGSgaQKU0iApQqFGCkELgoAAoAHj+caWxHTK/wDw6pbSb7lvl/gewPI86tPOm1ZdtOrRmn3Pa2c/3GOp+lH1nbx6Thcs8TTsrl1IQqfbhCfvSZsny7lt6selMJ/XJkuTApYxkrZMkZGzcee0yRjJi5G+3bHfpxTZg2ZT3nC548TpIzLKSZ5vl3b9Jp1/FY321SW/clsra/Q9BJnVa9T6S2uqT3qpbV6bXhKm1+prXwscOg1uktLOpnO3a28srem3Tib6Oi5CVFPTbBp5xQVP8DcP8Tv8HpxvxHViDLAKMQUoEBSAAUuAMQZADEGRAICgDVKcG0+8ZfeEc4yjgAGwU1jJSfewOcpwKoyqq+5AcxTi6bwKqq8QOTB0HL6jt6bex7qcZ/hqRl+h3qqLvOu5SwVSyvoJpuVpcY9PRtozlNyq7TkbcOpYafUfGVlbN+t0Uc/E72LPIc2dfb0uwf2aU6X/AI6kof4nrIs+N9vdfUrnTGTBMuTpHnzVsjYIdY8+SNmEmVs45M6RxyYzkalaZzTNapTk+EZe5nWPPM7M4xlPdxNWsk8p8HufoOWVCp9nCfe1H5nDUoyTw3FPDeM7TwsZ3LPeveblnL1R53mw8nTaVN8aNe6pP0qtJ/qerTPI83icI6rQlxoaxeRx3J7P6pnrDeH6x2Z5BEZGhMAyGAMRgywMAQpCgCFAEBSAAUAdbguDPo33BwfcVGAK0+5gCYBQBMAZGQKQm0RyArOK4htQnD7cJR96aMnIw2wOv5m5uemUkl5u4uabWVue3t4/vXvPoEaLPzFR5Vahp87q0srqdvR+mXE3GEKTfSZUW9pxbW6EVx7DWuuV+qVX5ep37z/DG6qwj+GLSPleObd/JlrT9U9C1vbSRp3WpWtFN1ry2pJcXUr04Y97Pyrd6lVmtirWqVnnL6WpKph/1M0owcurFy9WOfkWYxi21+orjltpFPrapaP7utGr+TJ1VfnT0SGcXc6jX2La4+bikfniFjXlwo1PbBpe9nLHSq+7MIr16kEvmaZ0+1VeeXTY7KjRvazSe01RowjJ+2eV7jr7rnwpLzOlzl41bmNP4KD+Z8znZ3Ek06lGCaw9lvh3bkzCGgN/7kn6lGcv2Ls7Y93dc994/M2NpT+9lVrfJxOquueDV59V2tLxp2+WvxuR59aBBJOTq4eUnLo6SbXHrMyWlW6Sbw08tOVwpZxx6iHyajYr84+sz62oVP6KVCn+WKOrr8p9RqZ6TUb6WeKd1Wx7trB2FO3tYb+joz7d8bmeGm1h5klndwZzVa9LEdmnTSaUl0Vrb0nnhhzeX+nALp6/mSu3OOowm3KXSW9Vyk23JyU023/Sj6ckfGtH1adCW3bylDqbajU29rC35UfJxlvt39y7Pp+ga7Tuopbo1kvKhndL+aPh4cV8T1dLL8dJXcAIp2QCKQC4LgiKQTAMhgDApcEwBAXAwUQFwANfAwUoRjgYMiBWOwu5e4jpruOTBcAcLorx95i6HpNgoGo7fx+Bi7aXgboQ2NB20u74nBVpSXFHbmvdUtpbuPzQ2PimvaJTVzcylDMp16tTGZJYlNyT3PxRrRhbwTxSo7UcZ+oqVZZ/7ksHveVWjuolVpr62nvWN3SR+yzxVzQUkqsI+UutFxi2/Y0954+rjcb/ABqNXpKa2nGOHtYShTt6Kb9EeHDuM+m3LZjKbl1IqtNtb8NSiorfw4fE45xXGO+L4R2tuUV2ZcYpN+gNOWcrbbaeZ7Ta8N78e7sXictjN1FtNKEWk1Jtqe1GHbulLDfFewxjcdZYhjL2ZKFOM4vfjinmPx8TFpYjvSXYpOnF+PDet/f3GbhKX8MpY3JZnPEezescPD/4wka9VrYUqjk5bUVHajKLXFblvXhnsOKplpJyyoYblJ4lvw875b2t29LgbX0Kq8/Vynni9lS37t6bZkrCrjGyoLOcTlTj8d7x4FRoOCztRUY7OMKKjCWUvJlhewycJRfdOS4NSp7KfGO/Cxh+jDN//TpYSlUppLcltzqpdvBFjp8V1quc8dim02vazQ6zYXDcks+U905cMeGUckISflLLaccOKknuWFJNLf8AM7JWtPvqPsWYwjjx3dviZxtY5zht5zlzlJ578thWnaxllvGWsuS7fFPylnidnY3jg4yhJQa8rdOEdl9myonJb28Fwpw/CjbibkHueTvKSNZRpV8QrPCjJrZjV/aXh2/A9GfJcnquT3KbZ2aN1LMeEKz4x8J+Hj7+87Y58pY9gMBb96x4YB0QAAFBABlgYCKBjgGTIBAABrgFKiFwChUKAQMFAAYBQBA0VgDQvrVNZx6f3Pn3KPSnRm7iC+rk/rorgn9tfr7+8+ntHUalaKScWspr4EykymqPl6s6b7JYb2sKc1HL7cZwZxtoLcoR9qTz7zavbR21Xon5ubboyfBfyfsYyjji1H1pKPzPDljcbppxKCXBJeguDCpc0o9etSj6Zp/LJq1NZtY8a8ZepFyf6CRG5OOUl3cM/I4cHBHVYS83Qu63qUJL9zbou6n5vSbmbfbUqxprHoxk3MbfUNOLBNk7Olo+qz6lhZ0c/wDJOpUa+ODdpcktVl1ru1ofc2sMr2mvHnwOghSlLqxk/QmzZp2NXtpyS75LZS956GHIK4n5/VbuXeqclTRtUubWy41ZXFd9rqV6m/4mp0sjbycq1OHXq0o445qRePccE9atI8biEvUUpP5H0W35C6bDGLOk8fbipP4naUNDtafUt6UfRCKNzp3k2+TR1mnLzdG7rd2xby3+3eb+mxuK8lFWNxRg/wCOqspf0rDPq0LSC4QivRFHKoLuNTpz7Nus5O206VFU5ycsNtZjKKivspOT3e07UYBtAYAAmAUACohQKAAGAUAaoCKEAAFCkAFBABUUiMgBCkYEMKtNSWGcgA6LV+TdK6g6dRyw+1YTT70dDDmysv8AclXqetVkvkz3ZSXV9jylvyA02H/Swl662vmdrb8nrSn1LelH0QR22Bgehr07SnHhCK9EUjlUEuw5AXYx2QkZEABAAUqIVAUAEAAoEABQKQAUApAAKBAZADURQCoAoChAABQAKiooAgAAhEUACgEAFAAjKACDAAhQABUQFGRQCAQAAACgAAKUAgpUABUAAP/Z";
            DAL_V2.Entity.Product[] products =
            {
                    new DAL_V2.Entity.Product
                    {
                        Id = productIds[0],
                        Name = "Laptop Lenovo Legion",
                        Price = 50000,
                        CategoryId = categoryIds[0],
                        Description = "Powerful laptop that let to enjoy the best AAA-games wherever you are",
                        ImgUrl = imgUrl
                    },
                    new DAL_V2.Entity.Product
                    {
                        Id = productIds[1],
                        Name = "Laptop ThinkPad carbon",
                        Price = 75000,
                        CategoryId = categoryIds[0],
                        Description = "Real working station that suits people who value quality and reliability",
                        ImgUrl = imgUrl
                    },
                    new DAL_V2.Entity.Product
                    {
                        Id = productIds[2],
                        Name = "Steam Deck",
                        Price = 20000,
                        CategoryId = categoryIds[0],
                        Description = "Portable game console can run any game on Steam even when traveling on an airplane or in the middle of the forest in a tent",
                        ImgUrl = imgUrl
                    },
                    new DAL_V2.Entity.Product
                    {
                        Id = productIds[3],
                        Name = "Garden Shears",
                        Price = 2500,
                        CategoryId = categoryIds[1],
                        Description = "Professional-grade garden shears for precise cutting and trimming",
                        ImgUrl = imgUrl
                    },
                    new DAL_V2.Entity.Product
                    {
                        Id = productIds[4],
                        Name = "Hedge Trimmer",
                        Price = 15000,
                        CategoryId = categoryIds[1],
                        Description = "Electric hedge trimmer for effortless shaping and maintenance of hedges",
                        ImgUrl = imgUrl
                    },
                    new DAL_V2.Entity.Product
                    {
                        Id = productIds[5],
                        Name = "Bleach Cleaner",
                        Price = 500,
                        CategoryId = categoryIds[2],
                        Description = "Powerful bleach cleaner for disinfecting and whitening surfaces",
                        ImgUrl = imgUrl
                    },
                    new DAL_V2.Entity.Product
                    {
                        Id = productIds[6],
                        Name = "All-Purpose Cleaner",
                        Price = 1000,
                        CategoryId = categoryIds[2],
                        Description = "Versatile all-purpose cleaner for effectively cleaning various surfaces",
                        ImgUrl = imgUrl
                    }
                };

            //CARTS
            Guid[] cartIds = new Guid[7];
            for (int i = 0; i < cartIds.Length; i++)
            {
                cartIds[i] = Guid.NewGuid();
            }
            DAL_V2.Entity.Cart[] carts =
            {
                    new DAL_V2.Entity.Cart
                    {
                        Id = cartIds[0],
                        UserId = userIds[0],
                        ProductId = productIds[0],
                    },
                    new DAL_V2.Entity.Cart
                    {
                        Id = cartIds[1],
                        UserId = userIds[0],
                        ProductId = productIds[2],
                    },
                    new DAL_V2.Entity.Cart
                    {
                        Id = cartIds[2],
                        UserId = userIds[0],
                        ProductId = productIds[3],
                    },
                    new DAL_V2.Entity.Cart
                    {
                        Id = cartIds[3],
                        UserId = userIds[1],
                        ProductId = productIds[3],
                    },
                    new DAL_V2.Entity.Cart
                    {
                        Id = cartIds[4],
                        UserId = userIds[1],
                        ProductId = productIds[5],
                    },
                    /*new DAL_V2.Entity.Cart
                    {
                        Id = cartIds[5],
                        UserId = userIds[1],
                        ProductId = productIds[5],
                    },*/
                    new DAL_V2.Entity.Cart
                    {
                        Id = cartIds[6],
                        UserId = userIds[1],
                        ProductId = productIds[1],
                    },
                };

            //WORDS
            Guid[] wordIds = new Guid[13];
            for (int i = 0; i < wordIds.Length; i++)
            {
                wordIds[i] = Guid.NewGuid();
            }
            DAL_V2.Entity.Word[] words =
            {
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[0],
                        Header = "computer",
                        KeyWord = "laptop"
                    },
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[1],
                        Header = "computer",
                        KeyWord = "Lenovo"
                    },
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[2],
                        Header = "computer",
                        KeyWord = "Thinkpad"
                    },
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[3],
                        Header = "computer",
                        KeyWord = "Legion"
                    },
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[4],
                        Header = "computer",
                        KeyWord = "game"
                    },
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[5],
                        Header = "computer",
                        KeyWord = "console"
                    },
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[6],
                        Header = "garden",
                        KeyWord = "scissors"
                    },
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[7],
                        Header = "garden",
                        KeyWord = "shears"
                    },
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[8],
                        Header = "garden",
                        KeyWord = "bushes"
                    },
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[9],
                        Header = "garden",
                        KeyWord = "trimmer"
                    },
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[10],
                        Header = "chemical",
                        KeyWord = "cleaner"
                    },
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[11],
                        Header = "chemical",
                        KeyWord = "bleach"
                    },
                    new DAL_V2.Entity.Word
                    {
                        Id = wordIds[12],
                        Header = "chemical",
                        KeyWord = "all-purpose"
                    }
                };

            //KEY PARAMS
            Guid[] keyParamsIds = new Guid[16];
            for (int i = 0; i < keyParamsIds.Length; i++)
            {
                keyParamsIds[i] = Guid.NewGuid();
            }
            DAL_V2.Entity.KeyParams[] keyParamses =
            {
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[0],
                        ProductId = productIds[0],
                        KeyWordsId = wordIds[0],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[1],
                        ProductId = productIds[0],
                        KeyWordsId = wordIds[1],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[2],
                        ProductId = productIds[0],
                        KeyWordsId = wordIds[3],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[3],
                        ProductId = productIds[1],
                        KeyWordsId = wordIds[1],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[4],
                        ProductId = productIds[1],
                        KeyWordsId = wordIds[2],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[5],
                        ProductId = productIds[2],
                        KeyWordsId = wordIds[4],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[6],
                        ProductId = productIds[2],
                        KeyWordsId = wordIds[5],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[7],
                        ProductId = productIds[3],
                        KeyWordsId = wordIds[6],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[8],
                        ProductId = productIds[3],
                        KeyWordsId = wordIds[7],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[9],
                        ProductId = productIds[3],
                        KeyWordsId = wordIds[8],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[10],
                        ProductId = productIds[4],
                        KeyWordsId = wordIds[8],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[11],
                        ProductId = productIds[4],
                        KeyWordsId = wordIds[9],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[12],
                        ProductId = productIds[5],
                        KeyWordsId = wordIds[10],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[13],
                        ProductId = productIds[5],
                        KeyWordsId = wordIds[11],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[14],
                        ProductId = productIds[6],
                        KeyWordsId = wordIds[10],
                    },
                    new DAL_V2.Entity.KeyParams
                    {
                        Id = keyParamsIds[15],
                        ProductId = productIds[6],
                        KeyWordsId = wordIds[12],
                    }
                };
            #endregion

            #region pushing data to db
            //Save data to Db
            foreach (DAL_V2.Entity.User user in users)
            {
                db.Add(user);
            }
            db.SaveChanges();

            foreach (DAL_V2.Entity.Category category in categories)
            {
                db.Add(category);
            }
            db.SaveChanges();

            foreach (DAL_V2.Entity.Product product in products)
            {
                db.Add(product);
            }
            db.SaveChanges();

            foreach (DAL_V2.Entity.Cart cart in carts)
            {
                db.Add(cart);
            }
            db.SaveChanges();

            foreach (DAL_V2.Entity.Word word in words)
            {
                db.Add(word);
            }
            db.SaveChanges();

            foreach (DAL_V2.Entity.KeyParams keyParams in keyParamses)
            {
                db.Add(keyParams);
            }
            db.SaveChanges();
            //Console.Out.WriteLine("Data was successfully written to db");

            #endregion
        }
    }
}