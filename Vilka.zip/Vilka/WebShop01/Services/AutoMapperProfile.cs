﻿using AutoMapper;
using BLL.Entity;
using WebShop01.Models;

namespace WebShop01.Services
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            //CreateMap<BLL.Entity.Product, ProductModel>().ReverseMap();
            //CreateMap<ProductCategory, CategoryModel>().ReverseMap();
            //CreateMap<KeyWord, ParamsModel>().ReverseMap();
            //CreateMap<CategoryInfo, CategoryInfoModel>().ReverseMap();
        }
    }
}
